import React, { Component } from 'react'

export class Contacto extends Component {
  render() {
    return (
      <div>Contacto</div>
    )
  }
}

export default Contacto