import React, { Component } from 'react'

export class Error extends Component {
  render() {
    return (
      <div>Pagina de error</div>
    )
  }
}

export default Error