import React, { Component } from 'react'

export class Menu extends Component {
  render() {
    return (
      <div>Menu</div>
    )
  }
}

export default Menu